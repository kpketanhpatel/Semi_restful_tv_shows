from __future__ import unicode_literals
from django.db import models
from datetime import datetime

class ShowManager (models.Manager):
    def basic_validator(self, form):
        errors = {}
        if len(form['title']) < 2:
            errors["title"] = "Title should be at least 2"
        if len(form['network']) < 2:
            errors:["network"] = "Network should be at least 2"
        if len(form['description']) < 2:
            errors:["description"] = "Description should be at least 2"
        if datetime.strptime(form['release_date'], '%Y-%m-%d') > datetime.now():
            errors:["release_date"] = "Release data should be in the past" 
        return errors    


# Create your models here.
class Show(models.Model):
    title = models.CharField(max_length=270)
    network = models.CharField(max_length=45)
    release_date = models.DateTimeField()
    description = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    objects = ShowManager()

